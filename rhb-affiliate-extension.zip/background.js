// Background (service worker): প্রোগ্রামের তালিকা সিঙ্ক + কখন ব্যানার দেখাবে তার সিদ্ধান্ত।
// গোপনীয়তা: ব্রাউজিং তথ্য কোথাও পাঠানো হয় না — শুধু প্রোগ্রামের পাবলিক তালিকা নামানো হয়, মেলানো হয় ব্রাউজারের ভেতরেই।
importScripts('config.js');

const SYNC_MS = 6 * 3600e3;          // ৬ ঘণ্টা পরপর তালিকা রিফ্রেশ
const SHOWN_MS = 30 * 60e3;          // ব্যানার দেখানোর পর ৩০ মিনিট আর নয়
const SNOOZE_MS = 24 * 3600e3;       // "এখন না" / "চালিয়ে যান" এর পর ২৪ ঘণ্টা
// এই প্যারামিটার থাকলে ধরে নিই অন্য কারো রেফারেল চলছে → ব্যানার দেখাব না
const AFF_PARAMS = ['ref', 'referral', 'referrer', 'aff', 'aff_id', 'affid', 'affiliate', 'affiliate_id', 'partner', 'partner_id', 'via', 'a_aid', 'a_bid', 'irclickid', 'clickid', 'click_id', 'cjevent', 'tduid', 'fpr', 'ranmid', 'sid', 'subid'];
// চেকআউট/পেমেন্ট ধাপে বিরক্ত করব না
const CHECKOUT = /(^|[\/_-])(cart|checkout|payment|payments|billing|basket|order|pay)([\/_.-]|$)/i;

const store = {
  get: (k) => chrome.storage.local.get(k),
  set: (o) => chrome.storage.local.set(o)
};

function parseCoupons(d) {
  let a = []; try { a = JSON.parse(d.coupons || '[]'); } catch (e) {}
  if (!Array.isArray(a) || !a.length) a = d.coupon ? [{ code: d.coupon }] : [];
  return a.filter((x) => x && x.code).map((x) => ({ code: String(x.code), note: x.note || '', expires: x.expires || '' }));
}
function couponValid(c) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(c.expires || ''); if (!m) return true;
  const t = new Date(), today = new Date(t.getFullYear(), t.getMonth(), t.getDate());
  return new Date(+m[1], m[2] - 1, +m[3]) >= today;
}

async function sync() {
  try {
    const j = await (await fetch(CFG.API + '?action=public')).json();
    if (!j || !j.ok) throw new Error('bad');
    const programs = (j.data || [])
      .filter((d) => d.matchDomains && d.affLink)
      .map((d) => ({
        id: String(d.id), company: d.company || '', slug: d.slug || '', affLink: d.affLink,
        domains: String(d.matchDomains).split(',').map((x) => x.trim().toLowerCase().replace(/^www\./, '')).filter(Boolean),
        coupons: parseCoupons(d)
      }))
      .filter((p) => p.domains.length);
    await store.set({ programs, syncedAt: Date.now() });
    return true;
  } catch (e) { return false; }
}

const hostMatches = (host, d) => host === d || host.endsWith('.' + d);

async function decide(href) {
  const no = { show: false };
  let { enabled = true, programs, syncedAt = 0, snooze = {} } = await store.get(['enabled', 'programs', 'syncedAt', 'snooze']);
  if (!enabled) return no;
  if (!programs || Date.now() - syncedAt > SYNC_MS) { await sync(); ({ programs } = await store.get('programs')); }
  if (!programs || !programs.length) return no;

  let u; try { u = new URL(href); } catch (e) { return no; }
  const host = u.hostname.toLowerCase().replace(/^www\./, '');
  const p = programs.find((x) => x.domains.some((d) => hostMatches(host, d)));
  if (!p) return no;

  const s = snooze[p.id]; if (s && (s.never || s.until > Date.now())) return no;
  if (CHECKOUT.test(u.pathname)) return no;
  const keys = [...u.searchParams.keys()].map((k) => k.toLowerCase());
  if (keys.some((k) => AFF_PARAMS.includes(k))) return no;                       // অন্য কারো রেফারেল
  if ((u.searchParams.get('utm_medium') || '').toLowerCase().includes('affiliate')) return no;
  try {                                                                           // ইতিমধ্যে আমাদের লিংকের প্যারামিটার থাকলে
    for (const [k, v] of new URL(p.affLink).searchParams) if (v.length >= 4 && u.searchParams.get(k) === v) return no;
  } catch (e) {}

  snooze[p.id] = { until: Date.now() + SHOWN_MS }; await store.set({ snooze });
  const coupon = p.coupons.find(couponValid) || null;
  return { show: true, id: p.id, company: p.company, url: p.slug ? CFG.BASE + '/' + p.slug : p.affLink, coupon: coupon ? { code: coupon.code, note: coupon.note } : null };
}

async function mark(id, mode) {
  const { snooze = {} } = await store.get('snooze');
  snooze[id] = mode === 'never' ? { never: true } : { until: Date.now() + SNOOZE_MS };
  await store.set({ snooze });
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  (async () => {
    if (msg.type === 'check') return send(await decide(msg.href));
    if (msg.type === 'mark') { await mark(msg.id, msg.mode); return send({ ok: true }); }
    if (msg.type === 'sync') return send({ ok: await sync() });
    send({});
  })().catch(() => send({ show: false }));
  return true;   // async response
});

chrome.runtime.onInstalled.addListener(() => { sync(); chrome.alarms.create('sync', { periodInMinutes: 360 }); });
chrome.runtime.onStartup.addListener(async () => { chrome.alarms.create('sync', { periodInMinutes: 360 }); const { syncedAt = 0 } = await store.get('syncedAt'); if (Date.now() - syncedAt > SYNC_MS) sync(); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'sync') sync(); });
