// এখানে শুধু এই দুটো বদলালেই হবে
const CFG = {
  API: 'https://script.google.com/macros/s/AKfycbzj28iGr42doZq9SlRDz4hjuSv8hbhCVG47aPjDDcpxxiJ6BpQlFbnpEO8suXXQjbocUA/exec',
  BASE: 'https://rakibulhaque.vercel.app'   // স্মার্ট লিংক: BASE/স্লাগ
};
