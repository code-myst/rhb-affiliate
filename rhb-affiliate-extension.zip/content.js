// Content script: মেলানো background-এ হয়; মিললে নিচে একটা ছোট ব্যানার (Shadow DOM — সাইটের স্টাইলের সাথে মিশে না)।
(async () => {
  if (window.top !== window || !/^https?:$/.test(location.protocol)) return;
  let r; try { r = await chrome.runtime.sendMessage({ type: 'check', href: location.href }); } catch (e) { return; }
  if (!r || !r.show) return;
  show(r);

  function el(tag, props, ...kids) { const e = document.createElement(tag); Object.assign(e, props || {}); kids.forEach((k) => e.append(k)); return e; }

  function show(r) {
    const host = el('div'); host.style.cssText = 'all:initial;position:fixed;left:0;right:0;bottom:16px;z-index:2147483647;display:flex;justify-content:center;pointer-events:none';
    const root = host.attachShadow({ mode: 'closed' });
    const css = el('style', { textContent: `
      *{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI","Hind Siliguri","Noto Sans Bengali",sans-serif}
      .b{pointer-events:auto;max-width:560px;width:calc(100% - 24px);background:#12121a;color:#fafafa;border:1px solid rgba(255,255,255,.14);border-radius:14px;padding:14px 16px;box-shadow:0 12px 40px rgba(0,0,0,.45);animation:in .25s ease}
      @keyframes in{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
      .t{font-size:14px;font-weight:700;margin:0 24px 4px 0}.d{font-size:12.5px;line-height:1.5;color:#b4b4c0;margin:0}
      .cp{margin-top:8px;display:inline-flex;gap:6px;align-items:center;font-size:12px;font-weight:600;color:#ddd6fe;background:rgba(139,92,246,.15);border:1px dashed rgba(167,139,250,.5);border-radius:8px;padding:5px 9px;cursor:pointer}
      .cp b{font-family:ui-monospace,Menlo,Consolas,monospace}
      .r{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
      button{cursor:pointer;border-radius:9px;font-size:13px;font-weight:600;padding:8px 14px;border:1px solid rgba(255,255,255,.18);background:transparent;color:#fafafa}
      button:hover{background:rgba(255,255,255,.08)}
      .p{background:#8b5cf6;border-color:#8b5cf6}.p:hover{background:#7c3aed}
      .l{border:none;color:#9a9aa8;font-weight:500;padding:8px 6px;text-decoration:underline}
      .x{position:absolute;right:8px;top:6px;border:none;font-size:16px;padding:4px 8px;color:#9a9aa8}
      .w{position:relative}` });
    const copy = r.coupon ? el('div', { className: 'cp', title: 'কপি করতে ক্লিক করুন' }, '🎟 কুপন: ', el('b', { textContent: r.coupon.code }), r.coupon.note ? ' · ' + r.coupon.note : '') : null;
    if (copy) copy.onclick = async () => { try { await navigator.clipboard.writeText(r.coupon.code); copy.firstChild.textContent = '✓ কপি হয়েছে: '; } catch (e) {} };

    const go = el('button', { className: 'p', textContent: 'চালিয়ে যান' });
    const later = el('button', { textContent: 'এখন না' });
    const never = el('button', { className: 'l', textContent: 'এই সাইটে আর না' });
    const close = el('button', { className: 'x', textContent: '✕', title: 'বন্ধ' });
    const done = (mode) => { chrome.runtime.sendMessage({ type: 'mark', id: r.id, mode }).catch(() => {}); host.remove(); };
    go.onclick = () => { chrome.runtime.sendMessage({ type: 'mark', id: r.id, mode: 'snooze' }).catch(() => {}); location.href = r.url; };
    later.onclick = () => done('snooze'); close.onclick = () => done('snooze'); never.onclick = () => done('never');

    const box = el('div', { className: 'b w' },
      close,
      el('p', { className: 't', textContent: r.company + '-এ কিনতে যাচ্ছেন?' }),
      el('p', { className: 'd', textContent: 'এটা আমাদের এফিলিয়েট লিংক — এই লিংক দিয়ে গেলে আপনার খরচ বাড়বে না, আর আমাদের কাজে সাপোর্ট হবে। ক্লিক না করলে কিছুই বদলাবে না।' }),
      ...(copy ? [copy] : []),
      el('div', { className: 'r' }, go, later, never));
    root.append(css, box); document.documentElement.append(host);
  }
})();
