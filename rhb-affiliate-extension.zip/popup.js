const $ = (id) => document.getElementById(id);
async function info() {
  const { programs = [], syncedAt = 0 } = await chrome.storage.local.get(['programs', 'syncedAt']);
  $('st').textContent = syncedAt ? `${programs.length} টি সাইট চেনা আছে · সর্বশেষ আপডেট: ${new Date(syncedAt).toLocaleString('bn-BD')}` : 'এখনো তালিকা আসেনি — "আপডেট" চাপুন';
}
(async () => {
  const { enabled = true } = await chrome.storage.local.get('enabled'); $('on').checked = enabled; info();
  $('on').onchange = () => chrome.storage.local.set({ enabled: $('on').checked });
  $('sync').onclick = async () => { $('st').textContent = 'আপডেট হচ্ছে…'; const r = await chrome.runtime.sendMessage({ type: 'sync' }); if (!r.ok) $('st').textContent = '⚠️ আপডেট হয়নি — ইন্টারনেট দেখুন'; else info(); };
  $('reset').onclick = async () => { await chrome.storage.local.set({ snooze: {} }); $('st').textContent = '✓ রিসেট হয়েছে — "এখন না/আর না" মুছে গেছে'; };
})();
